#define VERSION  "3.6.18"
#define VERSION_ "CalcHEP  " VERSION
