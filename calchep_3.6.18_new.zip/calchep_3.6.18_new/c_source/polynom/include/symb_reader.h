#ifndef __SYMB_READING_
#define __SYMB_READING_

#include"symb_tot.h"

typedef struct symb_data * symb_all;
extern symb_all rd_symb(char*s);
extern symb_data symb_read(char *);


#endif
