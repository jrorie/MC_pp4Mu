#ifndef __TENSOR_
#define __TENSOR_

extern tensor  multtwotens(tensor  t1, tensor  t2);
extern tensor  newtensor1(void);
extern int tensLength, maxIndex;

#endif
