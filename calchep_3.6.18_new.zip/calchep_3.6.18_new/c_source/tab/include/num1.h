
#ifndef __NUM1__
#define __NUM1__

#define MAXNP 20
#define NAMELEN 20

extern  char   p_names_[MAXNP][NAMELEN];
extern  int   p_codes_[MAXNP]; 
extern  double p_masses_[MAXNP];

#endif
