
#include"dynamic_cs.h"
int VVdecay=1;