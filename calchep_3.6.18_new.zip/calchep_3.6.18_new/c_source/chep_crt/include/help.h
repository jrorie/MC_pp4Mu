#ifndef __HELP__
#define __HELP__
  extern int show_help(char * fname);
  extern char pathtohelp[256];
#endif
