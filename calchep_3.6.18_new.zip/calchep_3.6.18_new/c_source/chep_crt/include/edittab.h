#ifndef EDITTAB_H
#define EDITTAB_H

extern int edittable(int x, int y, table *tab,int ntop,char* hlpf,int show);

#endif
