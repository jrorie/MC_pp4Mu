#ifndef __READER_FUNC__
#define __READER_FUNC__

extern int calcExpression(char*s,int(*nameToDouble)(char*,double*),double*p);   

#endif

