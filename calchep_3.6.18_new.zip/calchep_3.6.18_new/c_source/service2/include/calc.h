#ifndef __CALC_
#define __CALC_

extern char * userFuncTxt;
extern double userFuncNumC(void);
extern double userFuncNumI(double x);

#endif
