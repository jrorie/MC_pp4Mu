#ifndef _F_COMPARE_
#define _F_COMPARE_

extern int fcompare(char *f1, char*f2);

#endif
