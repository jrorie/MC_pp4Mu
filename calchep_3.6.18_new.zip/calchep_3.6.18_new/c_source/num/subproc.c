/*
 Copyright (C) 1997, Alexander Pukhov, e-mail pukhov@theory.npi.msu.su
*/

#include"subproc.h"

int Nsub=1;
char Process[100]="";


