#ifndef __qcdScale__
#define __qcdScale__

extern int initScales(char*strF,char*strR,char*mess);
extern void Scale(double*,double*,double*);

#endif
