#ifndef __CS_22_
#define __CS_22_

 extern int  cs_numcalc(double Pcm);

#endif
