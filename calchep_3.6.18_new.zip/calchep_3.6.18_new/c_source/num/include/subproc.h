#ifndef __SUBPROC__
#define __SUBPROC__
extern int Nsub;
extern  char Process[100];
#endif
