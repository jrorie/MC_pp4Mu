#ifndef _SHOW_SPECTRUM_
#define _SHOW_SPECTRUM_

extern void show_spectrum(int X, int Y);

#endif
