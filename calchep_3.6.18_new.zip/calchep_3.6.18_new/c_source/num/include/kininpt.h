#ifndef __KININPT__
#define __KININPT__
#include<stdio.h>

extern int entkin_(void);
extern void stdkin_(void);


extern int wrtkin_(FILE *nchan);
extern int rdrkin_(FILE *nchan);
#endif
