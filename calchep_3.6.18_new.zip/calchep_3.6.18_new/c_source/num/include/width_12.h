#ifndef __WIDTH_12_
#define __WIDTH_12_

extern void  decay12(void);
#endif
