#ifndef __MC_MENU__
#define __MC_MENU__
extern int monte_carlo_menu(void);
#endif
