#ifndef __SF_EPP__
#define __SF_EPP__
extern int p_epp__(int * pNum);
extern void n_epp__(int i, char *name);
extern int r_epp__(int i, char *name);
extern int m_epp__(int i, int*);
extern int mc_epp__(int i);
extern int  i_epp__(int i, double * be, double * mass);
extern double c_epp__(int i, double x,double q);
#endif
