#include"SLHAplus.h"

int FError=0;

