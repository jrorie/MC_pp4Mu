#ifndef __M_UTILS_
#define __M_UTILS_

extern int  clearresults(void);
extern void  fillModelMenu(void);
extern int  deletemodel(int n);
extern int  makenewmodel(void);
extern int  continuetest(void);
extern void     changeexitmenu(void);
extern void     new_user(void);
extern void     clear_tmp(void);

#endif
