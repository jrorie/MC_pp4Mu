#ifndef __DRAWDIAG__
#define __DRAWDIAG__

extern void  picture(int squared,void * buff, int x, int y);
extern void setPictureScale(int upr_, int * xn,int *ynu);

#endif
