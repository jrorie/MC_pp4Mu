#ifndef __R_CODE_AMPL__
#define __R_CODE_AMPL__
#include "amplitudes.h"

extern void makeReduceAmpl(int nsub, vamplExt * diagPtr);

#endif
