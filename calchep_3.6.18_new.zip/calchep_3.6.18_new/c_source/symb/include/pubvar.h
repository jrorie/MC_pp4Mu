
#ifndef _PUBVAR_
#define _PUBVAR_
extern int  nParProc;
#endif
