#ifndef __RED_OUT_
#define __RED_OUT_
/*	extern void  makeviewfile(char * fname); */
	extern void  makeReduceOutput(void);
#endif
