#ifndef __DIAPRINS_
#define __DIAPRINS_

extern void writeTextDiagram(vcsect* diagr,int label,char comment,FILE* outfile);
void writeAmDiagram(vampl* diag1,int label,char comment,FILE* outfile);


#endif
