#ifndef __L_STRING_
#define __L_STRING_

#include"syst2.h"

 extern void  fortwriter(char * name,varptr fortformula);
 extern int   write_const(void);
 extern int   cleardegnames(void);
 extern void  initdegnames(void);
 extern int tmpNameMax;

#endif
