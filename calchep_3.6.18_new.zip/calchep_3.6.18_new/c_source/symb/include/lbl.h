#ifndef __LBL_
#define __LBL_

extern  void  cheplabel(void);

#endif
