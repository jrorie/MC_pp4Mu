#ifndef __SYST2_
#define __SYST2_

#include"syst.h"

#define SSTRLEN 3000
typedef char shortstr[SSTRLEN];

extern void    revers(void *  * list);
extern void    lShift (char * s,int l);

#endif
