#ifndef __FORM_OUT_
#define __FORM_OUT_

extern void  makeFormOutput(void);

#endif
