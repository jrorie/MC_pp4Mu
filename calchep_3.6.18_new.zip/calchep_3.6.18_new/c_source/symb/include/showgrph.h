/*-------------------------------------------------*
 * C -version by Victor Edneral, Moscow University *
 *        The latest revision of 07.08.1995        *
 *-------------------------------------------------*/

#ifndef __SHOWGRPH_
#define __SHOWGRPH_


extern void showgraphs(char  upr);
/*  upr:=1(process),2(Q_diagrams) */ 


#endif
