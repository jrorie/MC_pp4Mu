#ifndef __C_OUT_
#define __C_OUT_

extern int  c_prog(void);

extern int noPict;
extern int noCChain;
extern int tWidths;
       
#endif
