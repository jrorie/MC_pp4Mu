#ifndef __CONSTR_
#define __CONSTR_

  extern int  construct(void);

#endif

