#ifndef __PREP_AMPL__
#define __PREP_AMPL__

#include "ghosts.h"
#include "diagrams.h"

extern void coloringAmpl(vampl * source, hlpcsptr ghostMap,  vampl* dest); 


#endif
