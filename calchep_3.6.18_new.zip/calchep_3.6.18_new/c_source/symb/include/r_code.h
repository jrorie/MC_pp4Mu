#ifndef __R_CODE_
#define __R_CODE_

extern void  mk_reduceprograms(void);
extern void  makeghostdiagr(int  dnum,char * fname);

#endif
