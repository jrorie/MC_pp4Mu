/*-------------------------------------------------*
 * C -version by Victor Edneral, Moscow University *
 *        The latest revision of 07.08.1995        *
 *-------------------------------------------------*/

#ifndef __SHOWGRPH2_
#define __SHOWGRPH2_


extern void showgraphs2(char  upr);
/*  upr:=1(process),2(Q_diagrams) */ 


#endif
