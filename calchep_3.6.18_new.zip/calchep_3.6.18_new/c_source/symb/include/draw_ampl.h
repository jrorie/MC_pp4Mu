#ifndef __DRAW_AMPL__
#define __DRAW_AMPL__
#include"diagrams.h"

extern int amplitudeFrameX(int nin, int nout);
extern int amplitudeFrameY(int nin, int nout);
extern void drawAmpitudeDiagram(vampl* diagr,int mode, int x, int y);

#endif
