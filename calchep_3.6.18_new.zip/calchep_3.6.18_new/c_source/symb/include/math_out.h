#ifndef __MATH_OUT_
#define __MATH_OUT_

extern void  makeMathOutput(void);

#endif

