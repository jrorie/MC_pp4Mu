#ifndef _NUM_CHECK_
#define _NUM_CHECK_

extern int numcheck(void);


#endif
