#ifndef __READER_C_
#define __READER_C_

extern void * act_c(char *  ch, int n, void ** args);
extern void * rd_c(char *  s);
extern FILE * ext_h;
extern int checkNaN;
#endif
