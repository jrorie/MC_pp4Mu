
#include "pubvar.h"

int nParProc=1; 
